module.exports = {
	testEnvironment: "node",
};
